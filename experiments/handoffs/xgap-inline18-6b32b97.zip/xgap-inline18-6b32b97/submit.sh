#!/usr/bin/env bash
# One explicit submission of the accepted inline18 release; never resubmit.
set -euo pipefail
set -o noclobber
PACKAGE_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
export XGAP_REPO_ROOT=/home/hxc859/XGAP-inline18-6b32b97
export XGAP_PYTHON=/home/hxc859/venvs/xgap-core/bin/python
export VLLM_ENV=/home/hxc859/venvs/xgap-vllm
export HF_HOME=/home/hxc859/.cache/huggingface
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 HF_DATASETS_OFFLINE=1 HF_HUB_DISABLE_TELEMETRY=1
export XGAP_GRAILQA_GUARDED_RUNNER_COMMIT=6b32b973d4fd1a979b714570d3edcd2e684c1b07
export XGAP_GRAILQA_GUARDED_SPEC="$XGAP_REPO_ROOT/experiments/specs/grailqa_semantic_preflight_inline_grounding_v1_cwru_qwen3_32b.json"
export XGAP_GRAILQA_GUARDED_SPEC_SHA256=0d3e89524b3422f7d8816e383b7ea7483265f61f531586a8a80a516edfa223e7
export XGAP_GRAILQA_LOCAL_PREFLIGHT_ROOT=/home/hxc859/xgap-data/freebase/grailqa-local-catalog-v1/preflight18
export XGAP_GRAILQA_PREFLIGHT_ARTIFACT_PROFILE=query_local_e3b4
export XGAP_GRAILQA_CATALOG_V2="$XGAP_GRAILQA_LOCAL_PREFLIGHT_ROOT"
export XGAP_GRAILQA_REACHABILITY_V2="$XGAP_GRAILQA_LOCAL_PREFLIGHT_ROOT"
export XGAP_GRAILQA_REACHABILITY_SUMMARY="$XGAP_GRAILQA_LOCAL_PREFLIGHT_ROOT/audit_summary.json"
export XGAP_GRAILQA_REACHABILITY_ROWS="$XGAP_GRAILQA_LOCAL_PREFLIGHT_ROOT/reachability.jsonl"
export XGAP_LLM_MODEL=Qwen/Qwen3-32B XGAP_LLM_BASE_URL=http://127.0.0.1:8000/v1
unset XGAP_CWRU_RUN_ROOT XGAP_CWRU_CONTRACT XGAP_MODEL_REVISION XGAP_RESOLVED_MODEL_REVISION
[[ -x "$XGAP_PYTHON" && -x "$VLLM_ENV/bin/python" && -x "$VLLM_ENV/bin/vllm" ]]
[[ ! -e "$XGAP_REPO_ROOT" && ! -L "$XGAP_REPO_ROOT" ]]
[[ ! -e "$PACKAGE_ROOT/input_pins.json" && ! -e "$PACKAGE_ROOT/submission_intent.json" ]]

# This new checkout does not switch or modify XGAP-m15-465e2e2.
git clone --no-checkout --single-branch --branch codex/m13e4-grailqa-semantic-paper-protocol \
  https://github.com/anthonyche/XGAP.git "$XGAP_REPO_ROOT"
git -C "$XGAP_REPO_ROOT" checkout --detach "$XGAP_GRAILQA_GUARDED_RUNNER_COMMIT"
[[ "$(git -C "$XGAP_REPO_ROOT" rev-parse HEAD)" == "$XGAP_GRAILQA_GUARDED_RUNNER_COMMIT" ]]
[[ -z "$(git -C "$XGAP_REPO_ROOT" status --porcelain --untracked-files=all)" ]]
export PYTHONPATH="$XGAP_REPO_ROOT/src"

"$VLLM_ENV/bin/python" - "$PACKAGE_ROOT" <<'PY'
from datetime import datetime, timezone
import hashlib, json, os, re, sys
from pathlib import Path
from xgap.experiments.cwru_vllm import resolve_cached_model_revision
from xgap.experiments.grailqa_catalog_v2 import GrailQAInferenceCatalogV2
from xgap.experiments.grailqa_local_catalog import validate_local_catalog
from xgap.experiments.grailqa_preflight import GrailQAPreflightSpec, preflight_readiness
from xgap.llm.token_budget import LocalPinnedChatTokenizer

package = Path(sys.argv[1])
repo = Path(os.environ['XGAP_REPO_ROOT'])
catalog_root = Path(os.environ['XGAP_GRAILQA_CATALOG_V2'])
validate_local_catalog(catalog_root)
catalog = GrailQAInferenceCatalogV2.load(catalog_root)
if catalog.catalog_hash != 'fa07c25b60558f81faef4116c768115d6e9419015f5e3e455f927f62820308e8':
    raise ValueError('Preserved v1 catalog identity changed; no submission.')
spec = GrailQAPreflightSpec.load(Path(os.environ['XGAP_GRAILQA_GUARDED_SPEC']))
if spec.data['freeze_hash'] != os.environ['XGAP_GRAILQA_GUARDED_SPEC_SHA256'] or len(spec.question_ids) != 18:
    raise ValueError('Frozen inline18 spec mismatch; no submission.')
if not preflight_readiness(spec, repo, require_credentials=False)['ready']:
    raise ValueError('Offline readiness failed; no submission.')
revision = resolve_cached_model_revision(model='Qwen/Qwen3-32B', hf_home=os.environ['HF_HOME'])
if re.fullmatch('[0-9a-f]{40}', revision) is None:
    raise ValueError('Expected an exact cached model revision.')
snapshot = Path(os.environ['HF_HOME']) / 'hub/models--Qwen--Qwen3-32B/snapshots' / revision
identity = LocalPinnedChatTokenizer(snapshot, revision).identity
pins = {
    'schema_version': 'xgap-inline18-launch-inputs-v1',
    'captured_at': datetime.now(timezone.utc).isoformat(),
    'runner_commit': os.environ['XGAP_GRAILQA_GUARDED_RUNNER_COMMIT'],
    'repo_root': str(repo), 'spec_path': str(spec.path),
    'spec_freeze_hash': spec.data['freeze_hash'], 'question_ids': list(spec.question_ids),
    'catalog_root': str(catalog_root), 'catalog_hash': catalog.catalog_hash,
    'catalog_manifest_sha256': hashlib.sha256((catalog_root/'manifest.json').read_bytes()).hexdigest(),
    'reachability_root': os.environ['XGAP_GRAILQA_REACHABILITY_V2'],
    'tokenizer_snapshot': str(snapshot), 'tokenizer_revision': revision,
    'tokenizer_identity': identity,
    'backend_execution': False, 'paper_result': False, 'automatic_retries': 0,
}
with (package/'input_pins.json').open('x') as handle:
    json.dump(pins, handle, indent=2, sort_keys=True, allow_nan=False)
    handle.write('\n')
    handle.flush()
    os.fsync(handle.fileno())
print('Frozen v1 catalog and exact cached tokenizer pinned before submission.')
PY
export XGAP_MODEL_REVISION="$("$XGAP_PYTHON" -c 'import json,sys; print(json.load(open(sys.argv[1]))["tokenizer_revision"])' "$PACKAGE_ROOT/input_pins.json")"
"$XGAP_PYTHON" - "$PACKAGE_ROOT" <<'PY'
from datetime import datetime, timezone
import json, os, sys
from pathlib import Path
with (Path(sys.argv[1])/'submission_intent.json').open('x') as handle:
    json.dump({'requested_at': datetime.now(timezone.utc).isoformat(),
               'runner_commit': os.environ['XGAP_GRAILQA_GUARDED_RUNNER_COMMIT'],
               'submission_attempts_allowed': 1}, handle, indent=2)
    handle.write('\n'); handle.flush(); os.fsync(handle.fileno())
PY
if sbatch --parsable --chdir="$XGAP_REPO_ROOT" --export=ALL \
  "$XGAP_REPO_ROOT/scripts/slurm/run_grailqa_guarded_preflight.sbatch" \
  > "$PACKAGE_ROOT/submission.stdout" 2> "$PACKAGE_ROOT/submission.stderr"; then
  printf '0\n' > "$PACKAGE_ROOT/submission_exit_code.txt"
else
  SUBMISSION_CODE=$?
  printf '%s\n' "$SUBMISSION_CODE" > "$PACKAGE_ROOT/submission_exit_code.txt"
  printf 'Submission failed; preserved output. Do not rerun automatically.\n' >&2
  exit "$SUBMISSION_CODE"
fi
JOB_RECORD="$(cat "$PACKAGE_ROOT/submission.stdout")"
[[ "$JOB_RECORD" =~ ^[0-9]+(\;[^[:space:]]+)?$ ]]
printf 'Submitted inline18 job %s. Preserve this package and the new checkout.\n' "$JOB_RECORD"
printf 'After COMPLETED, run: bash "%s/audit.sh"\n' "$PACKAGE_ROOT"
