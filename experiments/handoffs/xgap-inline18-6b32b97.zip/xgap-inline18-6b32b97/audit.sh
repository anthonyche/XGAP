#!/usr/bin/env bash
# Run explicitly after completion. No resubmission, inference or backend call.
set -euo pipefail
PACKAGE_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
export PYTHONPATH=/home/hxc859/XGAP-inline18-6b32b97/src
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 HF_DATASETS_OFFLINE=1 HF_HUB_DISABLE_TELEMETRY=1
/home/hxc859/venvs/xgap-vllm/bin/python - "$PACKAGE_ROOT" <<'PY'
from pathlib import Path
import json, re, subprocess, sys
from xgap.experiments.grailqa_guarded_evidence import main
from xgap.llm.token_budget import LocalPinnedChatTokenizer

package = Path(sys.argv[1])
pins = json.loads((package/'input_pins.json').read_text())
if LocalPinnedChatTokenizer(Path(pins['tokenizer_snapshot']), pins['tokenizer_revision']).identity != pins['tokenizer_identity']:
    raise ValueError('Tokenizer files/template/libraries changed since the prelaunch pin.')
if (package/'submission_exit_code.txt').read_text().strip() != '0':
    raise ValueError('Submission did not complete successfully; inspect its retained logs.')
raw_job = (package/'submission.stdout').read_text().strip()
if re.fullmatch(r'[0-9]+(?:;[^\s;]+)?', raw_job) is None:
    raise ValueError('Expected one recorded Slurm job ID.')
job = raw_job.split(';')[0]
state = subprocess.run(['sacct', '-j', job, '--format=JobID,State,ExitCode,Elapsed,Start,End', '-P'],
                       check=True, capture_output=True, text=True).stdout
print(state, end='')
rows = [line.split('|') for line in state.splitlines() if line.split('|')[0] == job]
if len(rows) != 1 or rows[0][1:3] != ['COMPLETED', '0:0']:
    raise ValueError('Job is not COMPLETED with 0:0; do not infer a complete measurement.')
output = package/'audit'
output.mkdir(exist_ok=False)
(output/'scheduler.txt').write_text(state)
options = {
    'run-root': str(Path(pins['repo_root'])/'runs'/('cwru-grailqa-guarded-'+job)),
    'repo-root': pins['repo_root'], 'spec-path': pins['spec_path'],
    'expected-commit': pins['runner_commit'], 'expected-spec-freeze-hash': pins['spec_freeze_hash'],
    'catalog-root': pins['catalog_root'], 'expected-catalog-hash': pins['catalog_hash'],
    'expected-catalog-manifest-sha256': pins['catalog_manifest_sha256'],
    'reachability-root': pins['reachability_root'],
    'tokenizer-snapshot': pins['tokenizer_snapshot'], 'tokenizer-revision': pins['tokenizer_revision'],
}
arguments = [item for key, value in options.items() for item in ('--'+key, value)]
original_stdout = sys.stdout
with (output/'whole_run_evidence.json').open('x') as handle:
    try:
        sys.stdout = handle
        code = main(arguments)
    finally:
        sys.stdout = original_stdout
print('Whole-run evidence:', output/'whole_run_evidence.json', 'exit code:', code)
raise SystemExit(code)
PY
