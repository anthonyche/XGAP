# 固定 v1 catalog 的真实 inline18 实验

版本 `6b32b973d4fd1a979b714570d3edcd2e684c1b07` 已推送到现有 GitHub 分支。
本地验收：184 项针对性测试；2700 passed / 37 skipped；harness 与 19 个示例通过。

这是待执行任务包，尚未提交新服务器作业，没有新的模型结果。
当前 OnDemand 已有登录页面，但 Codex 浏览器控制读取页面连续超时。

把 `xgap-inline18-6b32b97.zip` 上传到服务器的 `/home/hxc859`，在 OnDemand 终端执行一次：

```bash
unzip -n ~/xgap-inline18-6b32b97.zip -d ~ && bash ~/xgap-inline18-6b32b97/submit.sh
```

脚本创建独立目录 `/home/hxc859/XGAP-inline18-6b32b97`，拉取并固定上述版本，
验证保留的 v1 catalog，保存其 manifest 指纹和实际缓存 tokenizer 身份，
再提交一次既有 GPU 入口。请求 1 个 H100、8 CPU、64 GB、最多 4 小时。
固定 18 题、Top-20 检索、提示 Top-4、最多 3 个候选、每题至多一次结构修复。
最多 36 次生成尝试和 36 次 tokenization 探测；启动健康检查另计。
不构建 catalog，不下载模型，不调用图后端，不执行 full150，不修改旧目录。

运行完成后执行：

```bash
bash ~/xgap-inline18-6b32b97/audit.sh
```

它读取该次作业状态，要求 COMPLETED / 0:0，然后使用启动前保存的输入，
通过已测试的 D200 入口重算整次结果。报告位于
`~/xgap-inline18-6b32b97/audit/whole_run_evidence.json`。
请保留整个任务包目录、独立源码目录、Slurm 日志和 runs 目录。
任何失败都保留输出并停止；不要自动重复提交或删除文件后重试。

结果重点：18 题的有效候选与参考匹配、每阶段失败原因、实际调用与 token 成本。
有效候选或作业成功并不代表答案正确；真实答案执行是后续单独连接的工作。
任务包脚本经过本地语法和参数检查，尚未在 CWRU 上执行。
